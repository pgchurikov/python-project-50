#!/usr/bin/env python3


from gendiff.gendiff_help import help


def main():
    print(help())


if __name__ == '__main__':
    main()
