### Hexlet tests and linter status:
[![Actions Status](https://github.com/pgchurikov/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/pgchurikov/python-project-50/actions)

<a href="https://codeclimate.com/github/pgchurikov/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/0674c52e13a2c6429127/maintainability" /></a>

<a href="https://codeclimate.com/github/pgchurikov/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/0674c52e13a2c6429127/test_coverage" /></a>

[![GitHub Actions Demo](https://github.com/pgchurikov/python-project-50/actions/workflows/github-actions-demo.yml/badge.svg)](https://github.com/pgchurikov/python-project-50/actions/workflows/github-actions-demo.yml)

<a href="https://asciinema.org/a/668478" target="_blank"><img src="https://asciinema.org/a/668478.svg" /></a>